#include <iostream>
#include "/Users/Elah/Documents/CERN-2022/new_prefiring/mprefiring/src/sf_prefiring.h"

int main_prefiring() {

     // Setup analyzer
    std::string filePath = "/Users/Elah/Documents/CERN-2022/new_prefiring/mprefiring/output_new/L1prefiring_jetemptvseta_2016BtoH.json";
    sf_prefiring effAnalyzer;
    effAnalyzer.readFile(filePath);

    // Event loop
    float jet_eta = -3.1;
    float jet_pt = 20.0;
    //std::string hadronFlavour = "b";
    //std::string _datasetName = "DoubleEl";
    //std::string _fallbackDataset = "DoubleEl";

    // Class calibration
    //effAnalyzer.calib(_datasetName, _fallbackDataset);

    // Eval
    double eff = effAnalyzer.getEfficiency("L1prefiring_jetemptvseta_2016BtoH",jet_eta, jet_pt);
    std::cout << "eff: " << eff << std::endl;
    
}
