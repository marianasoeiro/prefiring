/*
*
 * btageffanalyzer.h
 *
 * URL:      https://github.com/gabrielmscampos/btageffanalyzer
 * Version:  2.0.0
 *
 * Copyright (C) 2021-2021 Gabriel Moreira da Silva Campos <gabrielmscampos@gmail.com>
 *
 * btageffanalyzer is distributed under the GPL-3.0 license, see LICENSE for details.
 *
 */

#include <iostream>
#include <vector>
#include <map>
#include <math.h>

#include "/Users/Elah/Documents/CERN-2022/new_prefiring/mprefiring/include/rapidjson/document.h"
#include "/Users/Elah/Documents/CERN-2022/new_prefiring/mprefiring/include/rapidjson/filereadstream.h"

class sf_prefiring {

    private:
        struct data {
            // float SF;
            // float SF_err;
            // float lep0_pt_max;
            // float lep0_pt_min;
            // float lep1_pt_max;
            // float lep1_pt_min;
            float pt_0_Min;
            float pt_0_Max;
            float pt_1_Min;
            float pt_1_Max;
            double eff;
            double eff_err;
        };
        
        struct bounds {
            float pt_0_Min;
            float pt_0_Max;
            float pt_1_Min;
            float pt_1_Max;
        };

        double evalEfficiency(
            std::string datasetName,
            float pt_0,
            float pt_1
        ) {
            const auto &entries = dataMap.at(datasetName);
            for (const auto &e: entries) {
                std::cout<<"pt value "<< pt_1 <<" eta value "<< pt_0 <<std::endl;
                std::cout<<"eta min: "<< e.pt_0_Min <<" eta max: "<< e.pt_0_Max <<" pt min: "<< e.pt_1_Min<< " pt max: "<<e.pt_1_Max<<" eff value: "<< e.eff <<std::endl;
                if (
                    pt_0 >= e.pt_0_Min &&
                    pt_0 <= e.pt_0_Max &&
                    pt_1 >= e.pt_1_Min &&
                    pt_1 < e.pt_1_Max
                ) {
                    return e.eff;
                }
            }
            return 0.;
        }

    public:
        std::map<std::string, std::vector<data>> dataMap;
        std::map<std::string, bounds> boundsMap;

        void readFile(
            std::string fpath
        ){
            rapidjson::Document effFileMap;
            FILE *fp_cert = fopen(fpath.c_str(), "r"); 
            char buf_cert[0XFFFF];
            rapidjson::FileReadStream input_cert(fp_cert, buf_cert, sizeof(buf_cert));
            effFileMap.ParseStream(input_cert);

            for (auto i = effFileMap.MemberBegin(); i != effFileMap.MemberEnd(); i++) {
                std::string dt = i->name.GetString();
                rapidjson::Value& dtValues = effFileMap[dt.c_str()];
                float minLeadingBound = 0.; float maxLeadingBound = 0.;
                float minSubleadingBound = -1.; float maxSubleadingBound = -1.;
                for (int j = 0; j < dtValues.Size(); j++) {
                    data te;
                    te.pt_0_Max = dtValues[j]["eta_min"].GetFloat();
                    te.pt_0_Min = dtValues[j]["eta_max"].GetFloat();
                    te.pt_1_Min = dtValues[j]["pt_min"].GetFloat();
                    te.pt_1_Max = dtValues[j]["pt_max"].GetFloat();
                    te.eff = dtValues[j]["value"].GetDouble();
                    te.eff_err = dtValues[j]["err"].GetDouble();
                    dataMap[dt].push_back(te);
                    minLeadingBound = minLeadingBound < te.pt_0_Min ? minLeadingBound : te.pt_0_Min;
                    maxLeadingBound = maxLeadingBound > te.pt_0_Max ? maxLeadingBound : te.pt_0_Max;
                    minSubleadingBound = minSubleadingBound < te.pt_1_Min ? minSubleadingBound : te.pt_1_Min;
                    maxSubleadingBound = maxSubleadingBound > te.pt_1_Max ? maxSubleadingBound : te.pt_1_Max;
                    if (minSubleadingBound < 0.) {
                        minSubleadingBound = te.pt_1_Min;
                        maxSubleadingBound = te.pt_1_Max;
                    }
                }
                bounds tb;
                tb.pt_0_Min = minLeadingBound;
                tb.pt_0_Max = maxLeadingBound;
                tb.pt_1_Min = minSubleadingBound;
                tb.pt_1_Max = maxSubleadingBound;
                boundsMap[dt] = tb;
            }

            fclose(fp_cert);
        }

        double getEfficiency(
            std::string datasetName,
            float pt_0,
            float pt_1
        ) {
            // Absolute value of eta
            pt_0 = fabs(pt_0);
            std::cout<<"eta "<<pt_0<<std::endl;
            std::cout<<"value of bounds "<<boundsMap.at(datasetName).pt_0_Min<<"-"<<boundsMap.at(datasetName).pt_0_Max<<std::endl;
            // If eta is out of bounds, return 0
            if (
                pt_0 < boundsMap.at(datasetName).pt_0_Min ||
                pt_0 > boundsMap.at(datasetName).pt_0_Max
            ) return 0;

            // If pt is out of bounds, define pt to evaluate next to bound
            float ptToEvaluate = pt_1;
            bool ptOutOfBounds = false;

            // If pt is lesser than minimum bound, return 0
            if (pt_1 < boundsMap.at(datasetName).pt_1_Min) return 0;


            // When given pT is greater then maximum boundary we compute
            // the efficiency at the maximum boundary
            if (pt_1 >= boundsMap.at(datasetName).pt_1_Max) {
                ptOutOfBounds = true;
                ptToEvaluate = boundsMap.at(datasetName).pt_1_Max - .0001;
            }

            std::cout<<"pt "<<pt_1<<std::endl;
            std::cout<<"value of bounds pt max "<<boundsMap.at(datasetName).pt_1_Max<<" and after correction  "<<ptToEvaluate<<std::endl;


            return evalEfficiency(datasetName, pt_0, ptToEvaluate);
        }
};
